package com.MovieService.movieservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class MovieService {
	
	@Autowired
	private MovieRepository repo;

	public Movie addMovie(Movie movie) {
		return repo.save(movie);
	}

	public List<Movie> getMovies() {
		return (List<Movie>) repo.findAll();
	}

	public Movie getMovie(Integer id) {
		return repo.findById(id).get();
	}

	public List<Movie> getMoviesBymovieName(String movieName) {
		return (List<Movie>) repo.findBymovieName(movieName);
	}
	
	public void deleteByMovieId(Integer id) {
		repo.deleteById(id);
	}
	
	public Movie updateMovie(Integer id,Movie movie) {
		movie.setMovieId(id);
		return repo.save(movie);
	}
			
}


