package com.MovieService.movieservice;

import java.util.List;

import org.springframework.data.repository.CrudRepository;



public interface MovieRepository extends CrudRepository<Movie, Integer>{
	public List<Movie> findBymovieName(String movieName);
}
