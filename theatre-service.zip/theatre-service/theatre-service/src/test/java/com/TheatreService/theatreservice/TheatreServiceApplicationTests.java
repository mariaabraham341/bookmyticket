package com.TheatreService.theatreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
