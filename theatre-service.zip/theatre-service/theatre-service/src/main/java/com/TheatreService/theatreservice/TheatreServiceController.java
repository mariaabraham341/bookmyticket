package com.TheatreService.theatreservice;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class TheatreServiceController {

	
	@Autowired
	private TheatreService service;
	
	@PostMapping(value ="/addtheatre")
	public ResponseEntity<Theatre> addTheatre(@Valid @RequestBody Theatre theatre){
		return new ResponseEntity<>(service.addTheatre(theatre),HttpStatus.OK);
	}

	@GetMapping(value ="/listAllTheatre")
	public ResponseEntity<List<Theatre>> getTheatre(){
		return new ResponseEntity<>(service.getTheatre(),HttpStatus.OK);
	}

	@GetMapping(value ="/theatre/{id}")
	public ResponseEntity<Theatre> getTheatreById(@PathVariable("id") Integer id){
		return new ResponseEntity<>(service.getTheatre(id),HttpStatus.OK);
	}
	
	
	@RequestMapping(method=RequestMethod.PUT, value="/updateTheatre/{id}")
    public ResponseEntity<Theatre> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Theatre theatre){
        return new ResponseEntity<>(service.updateTheatre(id,theatre), HttpStatus.OK);
    }

	@GetMapping(value ="/theatre/name/{theatrename}")
	public ResponseEntity<List<Theatre>> getTheatreByTheatrename(@PathVariable("theatrename") String theatrename){
		return new ResponseEntity<>(service.getTheatreByTheatrename(theatrename),HttpStatus.OK);
	}
	
	@DeleteMapping(path = "/theatre/{id}")
    public ResponseEntity <Void> deleteUser(@PathVariable("id") Integer id){
    service.deleteByTheatreId(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
		
	}
}
