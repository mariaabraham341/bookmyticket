package com.infy.bookingservice;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;


@RestController
public class BookingController {
	
	@Autowired
	private BookingService service;

	@PostMapping(value ="/addshow")
	public ResponseEntity<Show> addShow(@RequestBody Show show) {
		return new ResponseEntity<>(service.addShow(show),HttpStatus.OK);
	}
	
	@GetMapping(value ="/Allshows")
	public ResponseEntity<List<Show>> getShows(){
		return new ResponseEntity<>(service.getAllShows(),HttpStatus.OK);
	}
	
	@GetMapping(value ="/show/{id}")
    public ResponseEntity<Show> getShowById(@PathVariable("id") Integer id){
        return new ResponseEntity<>(service.getShow(id),HttpStatus.OK);
    }
	
	@GetMapping(path = "/getshow/{movieId}")
	   public ResponseEntity<List<Show>> findShowByMoive(@PathVariable("movieId") Integer movieId){
	       return new ResponseEntity<>(service.findShowByMoive(movieId),HttpStatus.OK);
	   }
	@GetMapping(path = "/getshowbytheatre/{theatreId}")
	   public ResponseEntity<List<Show>> findShowByTheatre(@PathVariable("theatreId") Integer theatreId){
	       return new ResponseEntity<>(service.findShowByTheatre(theatreId),HttpStatus.OK);
	   }

 
    @RequestMapping(method=RequestMethod.PUT, value="/updateshow/{id}")
    public ResponseEntity<Show> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Show show){
        return new ResponseEntity<>(service.updateshowDetails(id, show), HttpStatus.OK);
    }
    
    @DeleteMapping(path = "/show/{id}")
    public ResponseEntity <Void> deleteShow(@PathVariable("id") Integer id){
    service.deleteShow(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
        
    }
	
    @PostMapping(value ="/addbooking")
    public ResponseEntity<Booking> addBooking(@Valid @RequestBody Booking booking) throws Exception {
        try {
        return new ResponseEntity<>(service.addBooking(booking),HttpStatus.OK);
        }
        catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(), e);
        }
    }
	
	@GetMapping(value ="/Allbooking")
	public ResponseEntity<List<Booking>> getBooking(){
		return new ResponseEntity<>(service.getBookings(),HttpStatus.OK);
	}
	
	 @GetMapping(path = "/getbooking/{fromDate}/{toDate}")
	   public ResponseEntity<List<Booking>> getBookings(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate){
	       return new ResponseEntity<>(service.getBookingsbytdate(fromDate,toDate),HttpStatus.OK);
	   }
	
	@DeleteMapping(path = "/cancelbooking/{id}")
    public ResponseEntity <Void> cancelBooking(@PathVariable("id") Integer id){
    service.deleteBooking(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
        
    }
}
